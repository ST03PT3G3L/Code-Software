﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using _Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Threading;

namespace Proftaak_Software
{
    public partial class Form1 : Form
    {
        string KlantenDatabase = "{0, -15}{1, -30}{2, -45}";
        int[] Kolom = new int[0];
        int[] Rij = new int[0];

        Thread th;
        public Form1()
        {
            InitializeComponent();
        }

        public void OpenFile()
        {
            Excel excel = new Excel(Convert.ToString(listBox2.SelectedItem), 1);

            string Bedrijfsnaam, Locatie, Veiligheidsrisico;
            for (int i = 0; i < excel.ColumnCellAmount(); i++)
            {
                Bedrijfsnaam = excel.ReadCell(i, 0);
                Locatie = excel.ReadCell(i, 1);
                Veiligheidsrisico = excel.ReadCell(i, 2);
                listBox1.Items.Add(string.Format(KlantenDatabase, Bedrijfsnaam, Locatie, Veiligheidsrisico));
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedIndex >= 0)
            {
                OpenFile();
            }
            else { MessageBox.Show("Kies een bestand.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        public void WriteData()
        {
            Excel excel = new Excel(@"C:\Users\Mathijs\Desktop", 1);

            excel.WriteToCell(0, 0, "Test2");
            excel.Save();
            excel.SaveAs(@"C:\Users\Mathijs\Desktop\Hoi");

            excel.Close();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            WriteData();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add(string.Format(KlantenDatabase, "Bedrijfsnaam", "Locatie", "Veiligheidsrisico"));
        }

        private void Button3_Click_1(object sender, EventArgs e)
        {
            {
                FolderBrowserDialog FBD = new FolderBrowserDialog();

                if (FBD.ShowDialog() == DialogResult.OK)
                {
                    listBox2.Items.Clear();
                    string[] files = Directory.GetFiles(FBD.SelectedPath);
                    string[] dirs = Directory.GetDirectories(FBD.SelectedPath);

                    foreach (string file in files)
                    {
                        listBox2.Items.Add(file);
                    }
                    foreach (string dir in dirs)
                    {
                        listBox2.Items.Add(dir);
                    }
                }
            }
        }

        private void Form1_Deactivate(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(opennewform);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void opennewform(object obj)
        {
            System.Windows.Forms.Application.Run(new Form2());
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            
            th = new Thread(opennewform);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }
    }
}
