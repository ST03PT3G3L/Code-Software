﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using TxtOutput;

namespace Proftaak_Software
{
    public partial class Form2 : Form
    {
        Thread th;

        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                this.Close();
                th = new Thread(opennewform);
                th.SetApartmentState(ApartmentState.STA);
                th.Start();
            }
            else if(comboBox1.SelectedIndex == 1) 
            {
                this.Close();
                th = new Thread(opennewform2);
                th.SetApartmentState(ApartmentState.STA);
                th.Start();
            }

            
            
        }

        private void opennewform(object obj)
        {
            Application.Run(new Form1());
        }

        private void opennewform2(object obj)
        {
            Application.Run(new Form3());
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
